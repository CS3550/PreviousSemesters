package csci3550.t3;

/**
 * Holds the current state of the game--Either whose turn it is or how the game has ended.
 */
public enum GameState {
    XTurn,
    OTurn,
    GameTied,
    XWon,
    OWon
}
