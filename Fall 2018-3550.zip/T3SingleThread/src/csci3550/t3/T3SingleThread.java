package csci3550.t3;

import java.io.InputStream;
import java.io.PrintStream;
import java.util.Scanner;

public class T3SingleThread {
    public void run(InputStream is, PrintStream ps) {
        T3Model model = new T3Model();

        Scanner scanner = new Scanner(is);

        while (true) {

            for (int y = 0; y < 3; y++) {
                for (int x = 0; x < 3; x++) {
                    ps.print(" ");
                    SpaceState state = model.getSpaceState(x, y);
                    if (state == SpaceState.Empty)
                        ps.print(y * 3 + x);
                    else
                        ps.print(state);
                    if (x != 2)
                        ps.print(" |");
                }
                ps.println();
                if (y != 2)
                    ps.println("-----------");
            }

            ps.println();
            GameState gameState = model.getGameState();
            if (model.gameIsOver()) {
                if (gameState == GameState.OWon) {
                    ps.println("O won the game.");
                } else if (gameState == GameState.XWon) {
                    ps.println("X won the game.");
                } else {
                    ps.println("The game is tied.");
                }
                break;
            }

            ps.println();

            if (gameState == GameState.XTurn) {
                ps.println("X's turn.");
            } else {
                ps.println("O's turn.");
            }

            String line = scanner.nextLine();

            try {
                int move = Integer.parseInt(line);

                if (move < 0 || move > 8) {
                    ps.println(" Error: Your input must be between 0 and 8.");
                    continue;
                }

                int x = -1, y = -1;

                switch (move) {
                    case 0:
                        x = 0;
                        y = 0;
                        break;
                    case 1:
                        x = 1;
                        y = 0;
                        break;
                    case 2:
                        x = 2;
                        y = 0;
                        break;
                    case 3:
                        x = 0;
                        y = 1;
                        break;
                    case 4:
                        x = 1;
                        y = 1;
                        break;
                    case 5:
                        x = 2;
                        y = 1;
                        break;
                    case 6:
                        x = 0;
                        y = 2;
                        break;
                    case 7:
                        x = 1;
                        y = 2;
                        break;
                    case 8:
                        x = 2;
                        y = 2;
                        break;
                }

                model.go(x, y);

            } catch (NumberFormatException nfe) {
                ps.println("Error: Your input must be a number.");
            } catch (Exception e) {
                ps.println(e.getMessage());
            }
        }
        scanner.close();
    }

    public static void main(String[] args) {
        // System.out.println(new csci3550.t3.T3SingleThread().getGreeting());
        new T3SingleThread().run(System.in, System.out);
    }
}