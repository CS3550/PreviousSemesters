package csci3550.t3;

/**
 * The possible states that a space within a tic tac toe board can have
 */
public enum SpaceState {
    Empty,
    X,
    O
}
