package csci3550.t3;

import java.util.ArrayList;
import java.util.List;

/**
 * A model representing a tic tac toe board
 */
class T3Model {

    /**
     * Double array representing the board
     */
    private SpaceState[][] spaceState;

    /**
     * The current state of the board
     */
    private GameState gameState = null;

    /**
     * Default constructor that sets all the spaces in the board to empty.
     */
    T3Model(){

        spaceState = new SpaceState[3][3];
        for(int x = 0; x < 3; x++)
        {
            for(int y = 0; y < 3; y++)
            {
                spaceState[x][y] = SpaceState.Empty;
            }
        }
    }

    /**
     * Retreive the current state of the game.
     * @return Returns the current state of the game.
     */
    GameState getGameState() {

        //To save time, we cache the state of the game. If the state changes (by a player taking a turn)
        //The game state is set to null. When this happens, we recalculate the game state.
        if(gameState != null)
            return gameState;

        //By counting the number of X and O moves, we know a lot about the state of the board.
        int countX = 0;
        int countO = 0;

        for(int x = 0; x < 3; x++)
        {
            for(int y = 0; y < 3; y++)
            {
                SpaceState spaceState = getSpaceState(x,y);
                if(spaceState == SpaceState.X)
                    countX++;
                if(spaceState == SpaceState.O)
                    countO++;
            }
        }
        //Assuming that no one has won, if X and O have had the same number of turns,
        //Then it's Xs turn, otherwise, it's Os turn. There should never be a case
        //Where O has more turns than X. If X has had 5 turns and O has had 4 turns,
        //then the game is tied (again barring a win)
        if(countX == 5 && countO == 4)
        {
            gameState = GameState.GameTied;
        }
        else if(countX == countO)
        {
            gameState = GameState.XTurn;
        }
        else
        {
            gameState = GameState.OTurn;
        }

        //We have the correct game state, if no one has won. Now check for a victory
        //You win if you have three in a row vertical, horizontal, or diagonal
        //We put all the possible winning cases in a list and then check the list for wins
        List<SpaceState[]> possibleWins = new ArrayList<>();
        for(int x = 0; x < 3; x++)
        {
            SpaceState[] possibility = new SpaceState[3];
            for(int y = 0; y < 3; y++)
            {
                SpaceState spaceState = getSpaceState(x,y);
                possibility[y] = spaceState;

            }
            possibleWins.add(possibility);
        }

        for(int y = 0; y < 3; y++)
        {
            SpaceState[] possibility = new SpaceState[3];
            for(int x = 0; x < 3; x++)
            {
                SpaceState spaceState = getSpaceState(x,y);
                possibility[x] = spaceState;

            }
            possibleWins.add(possibility);
        }

        //Now check the two diagonals
        SpaceState[] possibility = new SpaceState[3];
        for(int i = 0; i < 3; i++)
        {
            possibility[i] = getSpaceState(i, i);
        }
        possibleWins.add(possibility);

        possibility = new SpaceState[3];
        for(int i = 0; i < 3; i++)
        {
            possibility[i] = getSpaceState(i, 2 - i);
        }
        possibleWins.add(possibility);

        //Now loop over all the possibilities and see if we have any winners
        //There's a winner if there are exactly three of the same type in one of the
        //three spaces found above.
        for(SpaceState[] p : possibleWins)
        {
            int cX = 0;
            int cO = 0;
            for(int i = 0; i < 3; i++)
            {
                if(p[i] == SpaceState.O)
                    cO++;
                if(p[i] == SpaceState.X)
                    cX++;
            }
            if(cX == 3)
                gameState = GameState.XWon;
            if(cO == 3)
                gameState = GameState.OWon;
        }

        return gameState;
    }

    /**
     * Get the state of a given space
     * @param x The x coordinate of the space
     * @param y The y coordinate of the space
     * @return The state of that space
     */
    SpaceState getSpaceState(int x, int y) {
        validateCoord(x);
        validateCoord(y);

        return spaceState[x][y];
    }

    /**
     * Throws an exception if a coordinate is invalid.
     * This method simplifies loops by not having to look for edge cases in the loops
     * @param coord
     */
    private void validateCoord(int coord) {
        if(coord < 0 || coord > 2)
            throw new IllegalArgumentException("All spaces must have coordinates of 0, 1, or 2");
    }

    /**
     * Check of a player can go in a space.
     * @param x The x coordinate of the space
     * @param y The y coordinate of the space
     * @return True of the space is unoccupied and the game is not over, false otherwise
     */
    boolean canGo(int x, int y) {
        return getSpaceState(x,y) == SpaceState.Empty && !gameIsOver();
    }

    /**
     * Check if the game is over (tied, x won, or o won).
     * @return True if the game is over, false otherwise
     */
    boolean gameIsOver() {
        GameState gameState = getGameState();
        return gameState == GameState.GameTied || gameState == GameState.XWon || gameState == GameState.OWon;
    }

    /**
     * The current player goes at the specified space. If the space is already occupied, an exception is thrown
     * @param x The x coordinate of the space
     * @param y The y coordinate of the space
     */
    void go(int x, int y) {
        if(!canGo(x,y))
            throw new IllegalArgumentException("You can not go in an occupied space.");
        if(gameIsOver())
            throw new IllegalArgumentException("You can not go when the game is over.");
        if(getGameState() == GameState.XTurn)
            spaceState[x][y] = SpaceState.X;
        else
            spaceState[x][y] = SpaceState.O;
        gameState = null; //This dirties the game state

    }
}
