/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 *
 * @author B Ricks, PhD <bricks@unomaha.edu>
 */
public class LockedBankAccount extends UnlockedBankAccount{

    Lock lock = new ReentrantLock();

    public void DepositCash(){
        
        for(int i = 0; i < 10000; i++){
            lock.lock();
            try{
            DepositADollar();
            }
            finally{
                lock.unlock();;
            }
        }
    }
    
}
