/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author B Ricks, PhD <bricks@unomaha.edu>
 */
public class Threads {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            // Serial code
            
            UnlockedBankAccount b = new UnlockedBankAccount();            
            b.DepositCash();            
            b.DepositCash();            
            System.out.println("Two sequential for loops:");            
            b.PrintBalance();
            
            //Thread code with unlocked code underneath.
            
            final UnlockedBankAccount b2 = new UnlockedBankAccount();
            
            Runnable Alice = ()->b2.DepositCash();            
            Runnable Bob = ()->b2.DepositCash();
            
            Thread AliceThread = new Thread(Alice);
            Thread BobThread = new Thread(Bob);
            
            AliceThread.start();
            BobThread.start();
            
            AliceThread.join();
            BobThread.join();
            
            System.out.println("Two threads unlocked");
            b2.PrintBalance();
            
            
            //Threaded code with locked code underneath
            final LockedBankAccount b3 = new LockedBankAccount();
            
            Runnable AliceLocked = ()->b3.DepositCash();
            Runnable BobLocked = ()->b3.DepositCash();
            
            Thread AliceThreadLocked = new Thread(AliceLocked);
            Thread BobThreadLocked = new Thread(BobLocked);
            
            AliceThreadLocked.start();
            BobThreadLocked.start();
            
            AliceThreadLocked.join();
            BobThreadLocked.join();
            
            System.out.println("Two threads locked");
            b3.PrintBalance();
            
        } catch (InterruptedException ex) {
            Logger.getLogger(Threads.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
