/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threads;

/**
 *
 * @author B Ricks, PhD <bricks@unomaha.edu>
 */
public class UnlockedBankAccount {
    
    protected int balance = 0;
    
    public void DepositADollar(){
        balance = balance + 1;
    }
    
    public void DepositCash(){
        for(int i = 0; i < 10000; i++){
            DepositADollar();
        }
    }
    
    public void PrintBalance(){
        System.out.println("Balance = " + balance);
    }
    
    
    
}
