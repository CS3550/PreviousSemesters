# Course
The main landing page for UNO CSCI 3550, Fall 2018

The syllabus, grading scale, and CS Policies (read them all) that apply to this course can be found here: https://github.com/bricksphd/teaching

Other information about the course will also crop up here as the semester progresses.

